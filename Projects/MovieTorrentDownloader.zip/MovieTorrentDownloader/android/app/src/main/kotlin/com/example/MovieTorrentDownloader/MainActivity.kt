package com.example.MovieTorrentDownloader

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
